(()=>{var a={};a.id=276,a.ids=[276],a.modules={261:a=>{"use strict";a.exports=require("next/dist/shared/lib/router/utils/app-paths")},3295:a=>{"use strict";a.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},7807:()=>{},8128:a=>{"use strict";a.exports=require("next/dist/server/runtime-reacts.external.js")},10846:a=>{"use strict";a.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},19121:a=>{"use strict";a.exports=require("next/dist/server/app-render/action-async-storage.external.js")},24082:(a,b,c)=>{"use strict";c.d(b,{$A:()=>d});let d={name:"ሄሎ ቴክኖሎጂ ማሰልጠኛ ማዕከል",englishName:"Hello Technology Training Center",brandSubtitle:"Hello Technology Training Center",tagline:"Build Practical Skills. Repair with Confidence.",phone:"09 47 74 70 70",alternatePhone:"09 82 48 43 28",email:"info@hellotechnology.edu.et",whatsappPhone:"251947747070",telegram:"https://t.me/Hellotechn",telegramHandle:"@HHaileHaile",facebook:"https://web.facebook.com/people/Hello-Technology-of-Institute-%E1%88%84%E1%88%8E-%E1%8B%A8%E1%88%99%E1%8B%AB-%E1%88%9B%E1%88%B0%E1%88%8D%E1%8C%A0%E1%8A%9B-%E1%89%B0%E1%89%8B%E1%88%9D/100063821901962/?locale=af_ZA",address:"ባ/ዳር ፓፒረስ ሆቴል ፊት ለፊት ሲግናል ሞል ህንፃ 4ኛ ፎቅ ቢሮ ቁ.409, Bahir Dar, Ethiopia",englishAddress:"Signal Mall Building, 4th Floor, Office No. 409 (In front of Papyrus Hotel), Bahir Dar, Ethiopia",googleMapsUrl:"https://maps.google.com/?q=Papyrus+Hotel+Bahir+Dar+Ethiopia",businessHours:"Monday – Friday: 8:30 AM – 5:30 PM | Saturday: 9:00 AM – 1:00 PM",specialPromotion:"በነፃ፦ ከሁለት በላይ ት/ት ለሚመዘገብ አንድ በነፃ (Register for more than two courses, get one free!)",accreditation:"ሙሉ ዕውቅና ያለው በሁሉም የትምህርት ዓይነት ደረጃ (Fully accredited for all educational levels)",cocCertifications:["Basic Electrical Electronics Equipment Level","Industrial Electrical Machines & Drives Servicing Level"],description:"ሄሎ ቴክኖሎጂ ማሰልጠኛ ማዕከል (Hello Technology Training Center) — Leading accredited technical trade and vocational training institute in Bahir Dar providing hands-on workshops in electronics, computing, electrical installations, digital media, coding, and industrial equipment maintenance.",mission:"To equip Ethiopian youth and professionals with accredited, job-ready technical trade skills, practical diagnostic problem-solving abilities, and hands-on lab excellence.",vision:"To be the most trusted center for accredited technical vocational education and hardware trade competence in East Africa.",brandColor:"#155DFC",brandColorName:"Electric Royal Blue",theme:{primary:"#155DFC",primaryHover:"#0D4ECC",white:"#FFFFFF",themeName:"Blue & White"}}},25226:(a,b)=>{"use strict";Object.defineProperty(b,"__esModule",{value:!0});var c={createCacheLifeOutsideUseCacheError:function(){return A},createCacheTagOutsideUseCacheError:function(){return z},createConnectionInPrivateUseCacheError:function(){return p},createConnectionInPublicUseCacheError:function(){return o},createConnectionInUnstableCacheError:function(){return q},createCookiesInUnstableCacheError:function(){return k},createCookiesInUseCacheError:function(){return j},createDraftModeMutationInUnstableCacheError:function(){return u},createDraftModeMutationInUseCacheError:function(){return t},createHeadersInUnstableCacheError:function(){return m},createHeadersInUseCacheError:function(){return l},createNestedCacheShortExpireError:function(){return C},createNestedCacheZeroRevalidateError:function(){return B},createRevalidateDuringRenderError:function(){return v},createRevalidateInBuildTimeGeneratorError:function(){return x},createRevalidateInCachedFunctionError:function(){return w},createRouteHandlerRequestInUnstableCacheError:function(){return s},createRouteHandlerRequestInUseCacheError:function(){return r},createSearchParamsInUseCacheError:function(){return n},createUseCachePrivateInsidePublicUseCacheError:function(){return D},createUseCachePrivateInsideUnstableCacheError:function(){return E},createUseCachePrivateOutsideRequestContextError:function(){return F}};for(var d in c)Object.defineProperty(b,d,{enumerable:!0,get:c[d]});let e="https://nextjs.org/docs/messages/next-request-in-use-cache",f="https://nextjs.org/docs/app/api-reference/functions/unstable_cache",g="https://nextjs.org/docs/messages/use-cache-private-composition",h="https://nextjs.org/docs/messages/revalidate-in-use-cache",i="https://nextjs.org/docs/messages/nested-use-cache-no-explicit-cachelife";function j(a){return Error(`Route "${a}": \`cookies()\` can't be read inside \`"use cache"\`. Read it outside the cached function and pass what you need as an argument.
Learn more: ${e}`)}function k(a){return Error(`Route "${a}": \`cookies()\` can't be read inside \`unstable_cache()\`. Read it outside the cached function and pass what you need as an argument.
Learn more: ${f}`)}function l(a){return Error(`Route "${a}": \`headers()\` can't be read inside \`"use cache"\`. Read it outside the cached function and pass what you need as an argument.
Learn more: ${e}`)}function m(a){return Error(`Route "${a}": \`headers()\` can't be read inside \`unstable_cache()\`. Read it outside the cached function and pass what you need as an argument.
Learn more: ${f}`)}function n(a){return Error(`Route "${a}": \`searchParams\` can't be read inside \`"use cache"\`. Await it outside the cached function and pass what you need as an argument.
Learn more: ${e}`)}function o(a){return Error(`Route "${a}": \`connection()\` can't be called inside \`"use cache"\` because cached functions may run during prerendering, without an incoming request. Call it outside the cached function.
Learn more: ${e}`)}function p(a){return Error(`Route "${a}": \`connection()\` can't be called inside \`"use cache: private"\` because private cached functions may run during prefetching, without a navigation request. Call it outside the cached function.
Learn more: https://nextjs.org/docs/app/api-reference/directives/use-cache-private`)}function q(a){return Error(`Route "${a}": \`connection()\` can't be called inside \`unstable_cache()\` because cached functions may run during prerendering, without an incoming request. Call it outside the cached function.
Learn more: ${f}`)}function r(a,b){return Error(`Route "${a}": \`${b}\` can't be read inside \`"use cache"\`. Read it outside the cached function and pass what you need as an argument.
Learn more: ${e}`)}function s(a,b){return Error(`Route "${a}": \`${b}\` can't be read inside \`unstable_cache()\`. Read it outside the cached function and pass what you need as an argument.
Learn more: ${f}`)}function t(a,b){return Error(`Route "${a}": \`${b}\` can't be called inside \`"use cache"\`. Draft mode can be read inside a cached function, but enabling or disabling it must happen outside.
Learn more: ${e}`)}function u(a,b){return Error(`Route "${a}": \`${b}\` can't be called inside \`unstable_cache()\`. Draft mode can be read inside a cached function, but enabling or disabling it must happen outside.
Learn more: ${f}`)}function v(a,b){return Error(`Route "${a}": \`${b}\` can't be called during render. Call it from a Server Action or Route Handler instead.
Learn more: ${h}`)}function w(a,b){return Error(`Route "${a}": \`${b}\` can't be called inside a cached function. Call it from a Server Action or Route Handler instead.
Learn more: ${h}`)}function x(a,b,c){return Error(`Route "${a}": \`${b}\` can't be called inside \`${c}\`. Call it from a Server Action or Route Handler instead.
Learn more: ${h}`)}function y(a){return void 0===a?"":`Route "${a}": `}function z(a){return Error(`${y(a)}\`cacheTag()\` can only be called inside a \`"use cache"\` or \`"use cache: private"\` function.
Learn more: https://nextjs.org/docs/messages/cache-tag-outside-use-cache`)}function A(a){return Error(`${y(a)}\`cacheLife()\` can only be called inside a \`"use cache"\` or \`"use cache: private"\` function.
Learn more: https://nextjs.org/docs/messages/cache-life-outside-use-cache`)}function B(a,b){return Error(`Route "${a}": A nested \`"use cache"\` with \`revalidate: 0\` is inside an outer \`"use cache"\` that has no \`cacheLife()\`. Add \`cacheLife()\` to the outer one to choose whether to prerender it with a non-zero \`revalidate\` or keep it dynamic with \`revalidate: 0\`.
Learn more: ${i}`,{cause:b})}function C(a,b){return Error(`Route "${a}": A nested \`"use cache"\` with a short \`expire\` (under 5 minutes) is inside an outer \`"use cache"\` that has no \`cacheLife()\`. Add \`cacheLife()\` to the outer one to choose whether to prerender it with a longer \`expire\` or keep it dynamic with a short \`expire\`.
Learn more: ${i}`,{cause:b})}function D(a){return Error(`Route "${a}": \`"use cache: private"\` can't be nested inside \`"use cache"\` because a shared cached function can't depend on private request data. Nest it only inside another \`"use cache: private"\`.
Learn more: ${g}`)}function E(a){return Error(`Route "${a}": \`"use cache: private"\` can't be used inside \`unstable_cache()\` because \`unstable_cache()\` uses a shared cache that can't contain private request data. Call the private cached function outside \`unstable_cache()\`.
Learn more: ${g}`)}function F(a,b){return Error(`Route "${a}": \`"use cache: private"\` needs an active request, so it can't be used during \`${b}\` or other build-time contexts. Move it to a request-time component or function.
Learn more: ${g}`)}},29021:a=>{"use strict";a.exports=require("fs")},29294:a=>{"use strict";a.exports=require("next/dist/server/app-render/work-async-storage.external.js")},33873:a=>{"use strict";a.exports=require("path")},44870:a=>{"use strict";a.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},53124:(a,b,c)=>{"use strict";c.r(b),c.d(b,{handler:()=>A,patchFetch:()=>z,routeModule:()=>v,serverHooks:()=>y,workAsyncStorage:()=>w,workUnitAsyncStorage:()=>x});var d=c(99057),e=c(85838),f=c(65925),g=c(65637),h=c(9807),i=c(52387),j=c(261),k=c(89093),l=c(6603),m=c(79789),n=c(37886),o=c(2144),p=c(2266),q=c(82872),r=c(52033),s=c(86439),t=c(3934),u=c(12751);let v=new d.AppRouteRouteModule({definition:{kind:e.RouteKind.APP_ROUTE,page:"/api/chat/route",pathname:"/api/chat",filename:"route",bundlePath:"app/api/chat/route"},distDir:".next",relativeProjectDir:"",resolvedPagePath:"C:\\Users\\leale\\Desktop\\Helloschool\\app\\api\\chat\\route.ts",nextConfigOutput:"",userland:()=>c(94695),...{}}),{workAsyncStorage:w,workUnitAsyncStorage:x,serverHooks:y}=v;function z(){return(0,f.patchFetch)({workAsyncStorage:w,workUnitAsyncStorage:x})}async function A(a,b,c){c.requestMeta&&(0,g.setRequestMeta)(a,c.requestMeta),v.isDev&&(0,g.addRequestMeta)(a,"devRequestTimingInternalsEnd",process.hrtime.bigint());let d="/api/chat/route";"/index"===d&&(d="/");let{instrumentation:e}=await v.ensureInstrumentation(a,{deferSpans:!0});return v.traceRequest(a,{tracer:(0,h.getTracer)(),spanName:`${a.method||"GET"} ${d}`,httpTarget:a.url,instrumentation:e},(e,f)=>B(a,b,c,d,!1,e,f))}async function B(a,b,c,d,f,w,x){let y=await v.prepare(a,b,{srcPage:d,multiZoneDraftMode:f});if(!y)return b.statusCode=400,b.end("Bad Request"),null==c.waitUntil||c.waitUntil.call(c,Promise.resolve()),null;let{buildId:z,deploymentId:A,params:B,nextConfig:C,parsedUrl:D,isDraftMode:E,prerenderManifest:F,routerServerContext:G,isOnDemandRevalidate:H,revalidateOnlyGenerated:I,resolvedPathname:J,clientReferenceManifest:K,serverActionsManifest:L,previewProps:M}=y,N=(0,j.normalizeAppPath)(d),O=!!F.routes[J]&&(v.isDev||(0,t.isRouteCacheOwner)(J,v.cacheOwner,F.routes[J])),P=!!(F.dynamicRoutes[N]||O),Q=async()=>((null==G?void 0:G.render404)?await G.render404(a,b,D,!1):b.end("This page could not be found"),null);if(P&&!E){let a=F.dynamicRoutes[N];if(a&&!1===a.fallback&&!O){if(C.adapterPath)return await Q();throw new s.NoFallbackError}}let R=null;!P||v.isDev||E||(R="/index"===(R=J)?"/":R),L&&K&&(0,i.setManifestsSingleton)({page:d,clientReferenceManifest:K,serverActionsManifest:L});let S=a.method||"GET",T=(0,h.getTracer)(),U=!!(null==G?void 0:G.isWrappedByNextServer),V=!!(0,g.getRequestMeta)(a,"minimalMode"),W=(0,g.getRequestMeta)(a,"incrementalCache")||await v.getIncrementalCache(a,C,M,F,V);null==W||W.resetRequestCache(),globalThis.__incrementalCache=W;let X={params:B,previewProps:M,renderOpts:{experimental:{authInterrupts:!!C.experimental.authInterrupts,useCacheTimeout:C.experimental.useCacheTimeout,durableUseCacheEntries:!!C.experimental.durableUseCacheEntries},cacheComponents:!!C.cacheComponents,validationLevel:C.experimental.instantInsights.validationLevel,isDraftMode:E,incrementalCache:W,hmrRefreshHash:(0,g.getRequestMeta)(a,"hmrRefreshHash"),cacheLifeProfiles:C.cacheLife,staticPageGenerationTimeout:C.staticPageGenerationTimeout,waitUntil:c.waitUntil,onClose:a=>{b.on("close",a)},onAfterTaskError:void 0},sharedContext:{buildId:z,deploymentId:A}},Y=new k.NodeNextRequest(a),Z=new k.NodeNextResponse(b),$=l.NextRequestAdapter.fromNodeNextRequest(Y,(0,l.signalFromNodeResponse)(b)),_=async({previousCacheEntry:e})=>{try{if(!V&&H&&I&&!e)return b.statusCode=404,b.setHeader("x-nextjs-cache","REVALIDATED"),b.end("This page could not be found"),null;let d=null===R?await v.handle($,X):await v.prerender($,X);a.fetchMetrics=X.renderOpts.fetchMetrics;let f=X.renderOpts.pendingWaitUntil;f&&c.waitUntil&&(c.waitUntil(f),f=void 0);let g=X.renderOpts.collectedTags;if(!P)return await (0,o.I)(Y,Z,d,f),null;{let a=await d.blob(),b=(0,p.toNodeOutgoingHttpHeaders)(d.headers);g&&(b[r.NEXT_CACHE_TAGS_HEADER]=g),!b["content-type"]&&a.type&&(b["content-type"]=a.type);let c=void 0!==X.renderOpts.collectedRevalidate&&!(X.renderOpts.collectedRevalidate>=r.INFINITE_CACHE)&&X.renderOpts.collectedRevalidate,e=void 0===X.renderOpts.collectedExpire||X.renderOpts.collectedExpire>=r.INFINITE_CACHE?!1!==c&&c>0?C.expireTime:void 0:X.renderOpts.collectedExpire;return{value:{kind:u.CachedRouteKind.APP_ROUTE,status:d.status,body:Buffer.from(await a.arrayBuffer()),headers:b},cacheControl:{revalidate:c,expire:e}}}}catch(b){throw(null==e?void 0:e.isStale)&&await v.onRequestError(a,b,{routerKind:"App Router",routePath:d,routeType:"route",revalidateReason:(0,n.getRevalidateReason)({isStaticGeneration:null!==R,isOnDemandRevalidate:H})},!1,G),b}},aa=async d=>{try{var f,g;let d=await v.handleResponse({req:a,nextConfig:C,cacheKey:R,routeKind:e.RouteKind.APP_ROUTE,isFallback:!1,previewProps:M,prerenderManifest:F,isRoutePPREnabled:!1,isOnDemandRevalidate:H,revalidateOnlyGenerated:I,responseGenerator:_,waitUntil:c.waitUntil,isMinimalMode:V});if(null!==d&&"error"in d)throw d.error;if(!P)return;if((null==d||null==(f=d.value)?void 0:f.kind)!==u.CachedRouteKind.APP_ROUTE)throw Error(`Invariant: app-route received invalid cache entry ${null==d||null==(g=d.value)?void 0:g.kind}`);V||b.setHeader("x-nextjs-cache",H?"REVALIDATED":d.isMiss?"MISS":d.isStale?"STALE":"HIT"),E&&b.setHeader("Cache-Control","private, no-cache, no-store, max-age=0, must-revalidate");let h=(0,p.fromNodeOutgoingHttpHeaders)(d.value.headers);V&&P||h.delete(r.NEXT_CACHE_TAGS_HEADER),!d.cacheControl||b.getHeader("Cache-Control")||h.get("Cache-Control")||h.set("Cache-Control",(0,q.getCacheControlHeader)(d.cacheControl)),await (0,o.I)(Y,Z,new Response(d.value.body,{headers:h,status:d.value.status||200}));return}catch(c){if(c instanceof s.NoFallbackError||await v.onRequestError(a,c,{routerKind:"App Router",routePath:N,routeType:"route",revalidateReason:(0,n.getRevalidateReason)({isStaticGeneration:null!==R,isOnDemandRevalidate:H})},!1,G),P)throw c;if(b.headersSent){if(d){let a=c instanceof Error?c:Error("Unknown app route error");d.recordException(a),d.setStatus({code:h.SpanStatusCode.ERROR,message:a.message}),d.setAttribute("error.type",a.name)}b.writableEnded||b.destroyed||b.end()}else await (0,o.I)(Y,Z,new Response(null,{status:500}));return}finally{(()=>{if(!d)return;let a=b.statusCode;d.setAttributes({"http.status_code":a,"next.rsc":!1}),a&&a>=500&&(d.setStatus({code:h.SpanStatusCode.ERROR}),d.setAttribute("error.type",a.toString()));let c=T.getRootSpanAttributes();if(!c)return;if(c.get("next.span_type")!==m.BaseServerSpan.handleRequest)return console.warn(`Unexpected root span type '${c.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let e=c.get("next.route")||N,f=`${S} ${e}`;d.setAttributes({"next.route":e,"http.route":e,"next.span_name":f}),d.updateName(f),x&&x!==d&&(x.setAttribute("http.route",e),x.updateName(f))})()}};U||void 0===a.url||null==w||w.setAttribute("http.target",a.url),await aa(w)}},55511:a=>{"use strict";a.exports=require("crypto")},63033:a=>{"use strict";a.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},68055:()=>{},86439:a=>{"use strict";a.exports=require("next/dist/shared/lib/no-fallback-error.external")},89449:(a,b,c)=>{"use strict";Object.defineProperty(b,"__esModule",{value:!0});var d={isRequestApiAllowedInCurrentPhase:function(){return l},throwForSearchParamsAccessInUseCache:function(){return k},throwWithStaticGenerationBailoutErrorWithDynamicError:function(){return j}};for(var e in d)Object.defineProperty(b,e,{enumerable:!0,get:d[e]});let f=c(51189),g=c(19121),h=c(3295),i=c(25226);function j(a,b){throw new f.StaticGenBailoutError(`Route ${a} with \`dynamic = "error"\` couldn't be rendered statically because it used ${b}. See more info here: https://nextjs.org/docs/app/building-your-application/rendering/static-and-dynamic#dynamic-rendering`)}function k(a,b){let c=(0,i.createSearchParamsInUseCacheError)(a.route);throw Error.captureStackTrace(c,b),a.invalidDynamicUsageError??=c,c}function l(a){switch(a.phase){case"action":case"render":return!0;case"after":{let a=g.actionAsyncStorage.getStore();if(a&&(a.isAppRoute||a.isAction))return!0;let b=h.afterTaskAsyncStorage.getStore();if(b)return"action"===b.rootTaskSpawnPhase;return!1}}}},94695:(a,b,c)=>{"use strict";c.r(b),c.d(b,{POST:()=>j,dynamic:()=>h});var d=c(61232),e=c(61958),f=c(24082),g=c(49641);let h="force-dynamic",i=["gemini-3.5-flash","gemini-flash-latest","gemini-3.7-flash","gemini-3.1-flash-lite"];async function j(a){try{let{messages:b}=await a.json();if(!b||!Array.isArray(b)||0===b.length)return d.NextResponse.json({error:"Messages are required"},{status:400});let c=b[b.length-1].content,[h,j]=await Promise.all([(0,g.vc)().catch(()=>[]),(e.A.batch?e.A.batch.findMany({where:{status:{in:["Open","Active","Upcoming"]}},orderBy:[{sortOrder:"asc"},{createdAt:"desc"}],take:3}):e.A.$queryRaw`
            SELECT * FROM Batch WHERE status IN ('Open', 'Active', 'Upcoming') ORDER BY sortOrder ASC, createdAt DESC LIMIT 3
          `.catch(()=>[])).catch(()=>[])]),k=h.map(a=>`• ${a.title} (Slug: ${a.slug}, Category: ${a.category}, Duration: ${a.duration||"Flexible"}, Price: ${a.price||"Contact for fee"} ETB). Description: ${a.description}. Prerequisites: ${a.prerequisites||"None"}. Learning Mode: 100% Self-Paced Online (24/7 Lifetime Access).`).join("\n");try{let a=c.match(/(?:09|\+2519|2519|07|\+2517|2517)\d{8}/);if(a){let b=a[0],d=c.match(/(?:my name is|ስሜ|name:?)\s+([A-Za-z\u1200-\u137F\s]{2,30})/i),f=d?d[1].trim():"Chatbot Visitor";await e.A.inquiry.create({data:{studentName:f,phone:b,course:"Chatbot Inquiry",message:`Lead captured via AI Chatbot: "${c.slice(0,300)}"`,status:"New",consent:!0}})}}catch(a){}let l=`You are "Hello Technology Assistant" (የሄሎ ቴክኖሎጂ ማሰልጠኛ ማዕከል ብልህ ረዳት), an enthusiastic, knowledgeable, and helpful official AI educational advisor for Hello Technology Training Center (ሄሎ ቴክኖሎጂ ማሰልጠኛ ማዕከል) in Bahir Dar, Ethiopia.

ABOUT THE CENTER:
- Institution Name: ${f.$A.name} (${f.$A.englishName} - ${f.$A.brandSubtitle})
- Motto / Tagline: ${f.$A.tagline} ("Build Practical Skills. Repair with Confidence.")
- Mission & Goal: To empower youth, students, and technicians with high-demand practical vocational skills (90%+ hands-on practical lab training) so they can become confident technicians, secure good employment, or start their own successful businesses in electronics and tech.
- Education Mode: 100% Self-Paced Online Technical Education. No fixed shifts or physical batch deadlines; students enroll online, learn anytime 24/7 at their own pace, get lifetime access, and receive official accredited certification upon completion.
- City & Address: ${f.$A.address} (በተለይ: ባሕር ዳር፣ ፓፒረስ ሆቴል ፊት ለፊት፣ ሲግናል ሞል ህንፃ 4ኛ ፎቅ ቢሮ ቁ.409)
- Phone Numbers: ${f.$A.phone} or ${f.$A.alternatePhone}
- Official Email: ${f.$A.email}
- Telegram Channel: ${f.$A.telegram} (Handle: ${f.$A.telegramHandle})
- WhatsApp: +${f.$A.whatsappPhone}

OFFICIAL ACCREDITED COURSES:
${k}

COURSE & DIGITAL ACCESS ENROLLMENT:
- Online Library & Courses: Students can browse all courses, video masterclasses, and technical schematics at /library.
- Instant Online Payment: Powered by Chapa (Telebirr, CBEBirr, Cards) for immediate instant unlocking.
- Creating an Account: Students can register their online student account at /auth/signup.

BEHAVIOR & GUIDELINES:
1. Always respond in the language the user speaks: if they write in Amharic (አማርኛ), respond fluently in polite, natural Amharic. If they write in English, respond in professional English.
2. Be warm, encouraging, respectful, and concise. Format responses with neat bullet points, bold highlights, and readable structure.
3. If asked "Who is Hello Technology Training Center?" or "What is the goal of Hello Technology?", give an inspiring, comprehensive overview of our institution, our practical hands-on mission, and the key fields we train in.
4. If recommending courses, mention practical modules, high-res schematics, and invite them to explore the online courses catalog at: /library.
5. If asked about prices or discounts, provide the figures from the catalog and note that online payment via Chapa is supported with instant activation.
6. If user asks for direct contact or calls, provide: ${f.$A.phone} and Telegram: ${f.$A.telegram}.`,m=process.env.GEMINI_API_KEY,n=process.env.OPENAI_API_KEY;if(m){let a=b.map(a=>({role:"assistant"===a.role?"model":"user",parts:[{text:a.content}]}));for(let b of i)try{let c=new AbortController,e=setTimeout(()=>c.abort(),8e3),f=await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${b}:generateContent?key=${m}`,{method:"POST",headers:{"Content-Type":"application/json"},signal:c.signal,body:JSON.stringify({system_instruction:{parts:[{text:l}]},contents:a,generationConfig:{temperature:.7,maxOutputTokens:1e3}})});if(clearTimeout(e),f.ok){let a=await f.json(),c=a?.candidates?.[0]?.content?.parts?.[0]?.text;if(c)return d.NextResponse.json({role:"assistant",content:c,provider:`gemini (${b})`})}}catch(a){console.warn(`Gemini model ${b} attempt failed:`,a)}}if(n)try{let a=await fetch("https://api.openai.com/v1/chat/completions",{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${n}`},body:JSON.stringify({model:"gpt-4o-mini",messages:[{role:"system",content:l},...b],temperature:.7,max_tokens:1e3})});if(a.ok){let b=await a.json(),c=b?.choices?.[0]?.message?.content;if(c)return d.NextResponse.json({role:"assistant",content:c,provider:"openai"})}}catch(a){console.warn("OpenAI API call failed, falling back:",a)}let o=function(a,b,c){let d=a.toLowerCase(),e=/[\u1200-\u137F]/.test(a);if(d.includes("who is")||d.includes("what is the goal")||d.includes("goal of hello")||d.includes("what does hello")||d.includes("totally what")||d.includes("about hello")||d.includes("ማን ነው")||d.includes("ዓላማ")||d.includes("ምን ይሰራል")||d.includes("ስለ ሄሎ")||d.includes("ስለ ተቋሙ"))return e?`🏛️ **ስለ ሄሎ ቴክኖሎጂ ማሰልጠኛ ማዕከል (Hello Technology Training Center):**

**ሄሎ ቴክኖሎጂ ማሰልጠኛ ማዕከል** በገበያው ውስጥ ተፈላጊ በሆኑ የቴክኖሎጂና ጥገና ሙያዎች ላይ የላቀ ተግባራዊ ክህሎት እንዲጨብጡ የተቋቋመ ግንባር ቀደም የስልጠና ማዕከል ነው።

🎯 **የተቋማችን ዋና ዓላማ:**
መሪ ቃላችን **"ተግባራዊ ክህሎት ይገንቡ፤ በእርግጠኝነት ይጠግኑ!" (Build Practical Skills. Repair with Confidence.)** እንደሚለው፤ ዋና ግባችን ሰልጣኞችን በተግባር የተደገፈ ጥራት ባለው ዲጂታል ስልጠና አብቅተን በራሳቸው ስራ ፈጣሪ ወይም በተለያዩ ድርጅቶች ውስጥ ተወዳዳሪ ባለሙያ ማድረግ ነው።

🛠️ **ተቋሙ በዋናነት ምን ይሰራል?**
1. **የሞባይል ስልክ ጥገና ስልጠና** (Hardware, Software, Micro-soldering)
2. **የኮምፒውተርና ላፕቶፕ ጥገና** (Motherboard, OS, Hardware troubleshooting)
3. **የኤሌክትሮኒክስና ቴሌቪዥን ጥገና** (Smart TV, LED/LCD, Refrigeration)
4. **የሶፍትዌር ኮዲንግና ፕሮግራሚንግ**
5. **የቪዲዮ ኤዲቲንግና ግራፊክስ ዲዛይን**

📍 **አድራሻ:** ባሕር ዳር፣ ፓፒረስ ሆቴል ፊት ለፊት፣ ሲግናል ሞል 4ኛ ፎቅ ቢሮ ቁ.409
📞 **ስልክ:** ${f.$A.phone} | 💬 **ቴሌግራም:** [${f.$A.telegramHandle}](${f.$A.telegram})

👉 [ስልጠናዎችን በዲጂታል ላይብረሪ ለመጀመር እዚህ ይጫኑ](/library)!`:`🏛️ **About Hello Technology Training Center & Our Mission:**

**Hello Technology Training Center** is a premier practical skills institute.

🎯 **Our Goal & Mission:**
Our motto is **"Build Practical Skills. Repair with Confidence."** Our core goal is to empower youth and professionals with hands-on, market-ready technical skills so they can start their own profitable repair businesses or secure high-paying technical jobs.

🛠️ **What Does Hello Technology Training Center Do?**
We specialize in intensive practical vocational education across two major branches:
1. **Hardware & Electronics Repair:**
   • Smartphone Repair (Hardware, Software, Micro-soldering)
   • Computer & Laptop Maintenance
   • Television & Electronics Diagnostics
   • Refrigerator & Cooling System Repair
2. **Digital Technologies:**
   • Coding & Software Programming
   • Video Editing & Digital Content Production

📍 **Campus Location:** Signal Mall 4th Floor (In front of Papyrus Hotel), Bahir Dar
📞 **Phone:** ${f.$A.phone} | 💬 **Telegram:** [${f.$A.telegramHandle}](${f.$A.telegram})

👉 [Click here to explore our Digital Academy & courses](/library)!`;if(d.includes("batch")||d.includes("intake")||d.includes("ዙር")||d.includes("ቀጣይ")||d.includes("መቼ")||d.includes("start")||d.includes("deadline"))return c[0],e?`📅 **የኦንላይን ኮርሶችና ማኑዋሎች መረጃ:**

በአሁኑ ወቅት ሁሉም የቪዲዮ ኮርሶች እና የቴክኒክ ሰርኪውት መመሪያዎች በኦንላይን ክፍት ናቸው!

• **ሁኔታ:** ክፍት ነው
• **የመማሪያ መንገድ:** በስልክ ወይም በኮምፒውተር 24/7 በራስዎ ፍጥነት
• **ክፍያ:** በቻፓ (Chapa) አማካኝነት በቴሌብር፣ በሲቢኢ ብር ወይም በባንክ ካርድ በቅጽበት ይከፈታል

👉 [ኦንላይን ኮርሶችን ለመመልከት እዚህ ይጫኑ](/library) ወይም በ **${f.$A.phone}** ይደውሉልን!`:`📅 **Online Courses & Technical Manuals:**

All practical video masterclasses and high-resolution schematics are open and accessible 24/7!

• **Format:** 100% Online, self-paced on your mobile phone or laptop
• **Activation:** Instant automatic unlocking via Chapa (Telebirr, CBEBirr, Cards)

👉 [Browse Online Courses & Manuals](/library) or call us at **${f.$A.phone}**!`;if(d.includes("mobile")||d.includes("phone")||d.includes("ሞባይል")||d.includes("ስልክ")){let a=b.find(a=>a.slug.includes("mobile")||a.title.includes("ሞባይል"));return e?`📱 **የሞባይል ስልክ ጥገና ስልጠና (Smartphone Repair Training):**

ይህ ስልጠና ከጀማሪ እስከ ከፍተኛ ደረጃ የሃርድዌርና የሶፍትዌር ጥገናን፣ ማይክሮ-ሶልደሪንግን (Micro-soldering) እና የስክሪን ቅየራን በተሟላ የቪዲዮ ትምህርት ያካትታል።

• **የሚሸፈኑ ርዕሶች:** የቦርድ ዲያግኖስቲክስ፣ አይሲ (IC) ማንሳትና መትከል፣ ፍላሽ ማድረግ፣ ኔትወርክና ባትሪ ጥገና
• **ቆይታ:** ${a?.duration||"በራስዎ ፍጥነት"}
• **ክፍያ:** ${a?.price||"ተመጣጣኝ"} ETB

👉 [ኮርሱን በኦንላይን ኮርሶች ለመጀመር እዚህ ይጫኑ](/library)!`:`📱 **Mobile Phone Repair Training Track:**

Comprehensive practical training covering hardware diagnostics, software troubleshooting, micro-soldering, and screen replacement.

• **Topics:** Board-level troubleshooting, IC rework, flashing, unlocking, power circuits
• **Duration:** ${a?.duration||"Self-paced"}
• **Tuition:** ${a?.price||"Affordable"} ETB

👉 [Start learning in Online Courses](/library)!`}if(d.includes("computer")||d.includes("laptop")||d.includes("ኮምፒውተር")||d.includes("ላፕቶፕ")){let a=b.find(a=>a.slug.includes("computer")||a.title.includes("ኮምፒውተር"));return e?`💻 **የኮምፒውተርና ላፕቶፕ ጥገና ስልጠና:**

ስለ ዴስክቶፕና ላፕቶፕ ኮምፒውተሮች ሃርድዌርና ሶፍትዌር ጥገና፣ ዊንዶውስ መጫን፣ የማዘርቦርድ ጥገናና የኔትወርክ መስመር ዝርጋታ በጥልቀት የሚያስተምር ተግባራዊ ስልጠና ነው።

• **ቆይታ:** ${a?.duration||"በራስዎ ፍጥነት"}

👉 [ኮርሱን በኦንላይን ለመጀመር እዚህ ይጫኑ](/library)!`:`💻 **Computer & Laptop Maintenance Training Track:**

Full training covering PC & laptop hardware repair, motherboard diagnostics, operating system installation, virus removal, and network cable configuration.

• **Duration:** ${a?.duration||"Self-paced"}

👉 [Click here to access online course](/library)!`}if(d.includes("where")||d.includes("location")||d.includes("address")||d.includes("አድራሻ")||d.includes("ቦታ")||d.includes("የት"))return e?`📍 **የሄሎ ቴክኖሎጂ ማሰልጠኛ ማዕከል አድራሻ:**

ባሕር ዳር ከተማ፣ **ፓፒረስ ሆቴል ፊት ለፊት**፣ **ሲግናል ሞል ህንፃ 4ኛ ፎቅ** ቢሮ ቁጥር **409**።

📞 **ስልክ ቁጥሮች:**
• ${f.$A.phone}
• ${f.$A.alternatePhone}

💬 **ቴሌግራም:** [${f.$A.telegramHandle}](${f.$A.telegram})

የቢሮ የስራ ሰዓት፡ ከሰኞ እስከ ቅዳሜ ከ 2:30 እስከ 12:00። በደስታ እንቀበልዎታለን!`:`📍 **Hello Technology Training Center Campus Location & Contact:**

Bahir Dar city, **opposite Papyrus Hotel**, **Signal Mall 4th Floor**, Office **#409**.

📞 **Phone:**
• ${f.$A.phone}
• ${f.$A.alternatePhone}

💬 **Telegram:** [${f.$A.telegramHandle}](${f.$A.telegram})

Office Hours: Monday - Saturday, 8:30 AM - 6:00 PM. You are warmly welcome to visit us!`;if(d.includes("register")||d.includes("enroll")||d.includes("sign up")||d.includes("how can i register")||d.includes("how to register")||d.includes("ምዝገባ")||d.includes("መመዝገብ")||d.includes("መስፈርት"))return e?`📝 **እንዴት መመዝገብና መማር ይቻላል? (How to Enroll):**

1. **በድረ-ገፃችን (Online 24/7):** በ [ኦንላይን ኮርሶች](/library) ገጽ ላይ የሚፈልጉትን ኮርስ ይምረጡ።
2. **ክፍያ መፈጸም:** በቻፓ (Chapa) በቴሌብር፣ በሲቢኢ ብር ወይም በባንክ ካርድ ይክፈሉ። ወዲያውኑ የቪዲዮ ትምህርቶች እና ማኑዋሎች ይከፈቱልዎታል!
3. **አካውንት መክፈት:** እስካሁን ካልተመዘገቡ በ [አካውንት መፍጠሪያ](/auth/signup) ላይ በ 1 ደቂቃ ውስጥ መመዝገብ ይችላሉ።

👉 [አሁኑኑ ኦንላይን ኮርሶችን ለመመልከት እዚህ ይጫኑ](/library)!`:`📝 **How to Enroll & Access Courses:**

1. **Browse Online Courses (24/7):** Visit our [Online Courses](/library) to select your desired course or technical manual.
2. **Instant Payment:** Pay securely via Chapa with Telebirr, CBEBirr, or Bank Cards. Access is unlocked immediately!
3. **Create Account:** If you don't have an account yet, sign up at [Create Account](/auth/signup).

👉 [Click here to browse online courses](/library)!`;if(d.includes("course")||d.includes("ስልጠና")||d.includes("ትምህርት")||d.includes("ምን ምን")){let a=b.map(a=>`• **${a.title}** (${a.duration||"2-3 ወራት"})`).join("\n");return e?`📚 **በሄሎ ቴክኖሎጂ ማሰልጠኛ ማዕከል የሚሰጡ ዋና ዋና የስልጠና ዘርፎች:**

${a||"• የሞባይል ስልክ ጥገና\n• የኮምፒውተርና ላፕቶፕ ጥገና\n• የቴሌቪዥንና ኤሌክትሮኒክስ ጥገና\n• የኮዲንግና ሶፍትዌር ፕሮግራሚንግ\n• የቪዲዮ ኤዲቲንግ"}

ስለ የትኛው ስልጠና በዝርዝር ማወቅ ይፈልጋሉ?`:`📚 **Official Courses Offered at Hello Technology Training Center:**

${a||"• Smartphone Repair & Maintenance\n• Computer & Laptop Maintenance\n• Television & Electronics Diagnostics\n• Coding & Software Programming\n• Video Editing"}

Which course would you like to learn more about?`}return e?`ሰላም! እንኳን ወደ **ሄሎ ቴክኖሎጂ ማሰልጠኛ ማዕከል** (Hello Technology Training Center) በደህና መጡ! 👋

እኔ የእርስዎ ብልህ የትምህርት ረዳት ነኝ። የሚከተሉትን ጥያቄዎች በደስታ እመልስልዎታለሁ፡

• 📱 **ስለ ስልጠና ዓይነቶችና ክፍያ** (የሞባይል ጥገና፣ ኮምፒውተር፣ ኤሌክትሮኒክስ፣ ኮዲንግ...)
• 📅 **የቀጣይ ዙር (Batch) መጀመሪያ ቀናት**
• ⏰ **የስልጠና ፈረቃዎች** (ጠዋት፣ ከሰዓት፣ ማታ፣ ቅዳሜና እሁድ)
• 📍 **አድራሻና ስልክ**

ስለምን ማወቅ ይፈልጋሉ? ከታች መጻፍ ይችላሉ፣ ወይም በቀጥታ በ **${f.$A.phone}** ይደውሉልን!`:`Hello and welcome to **Hello Technology Training Center**! 👋

I am your virtual educational advisor. I can help you with:

• 📱 **Courses & Tuition Fees** (Mobile Repair, Computer Maintenance, Electronics, Coding, Video Editing...)
• 📅 **Upcoming Batch Intakes & Start Dates**
• ⏰ **Class Shifts** (Morning, Afternoon, Evening, Weekend)
• 📍 **Campus Location & Directions**
• 📝 **Admissions & Online Registration**

How can I help you today? You can type your question below or call us at **${f.$A.phone}**!`}(c,h,j);return d.NextResponse.json({role:"assistant",content:o,provider:"knowledge-engine"})}catch(a){return console.error("Chat API Error:",a),d.NextResponse.json({error:"Failed to process chat message",details:a?.message},{status:500})}}},96330:a=>{"use strict";a.exports=require("@prisma/client")}};var b=require("../../../webpack-runtime.js");b.C(a);var c=b.X(0,[1314,4301,9641],()=>b(b.s=53124));module.exports=c})();